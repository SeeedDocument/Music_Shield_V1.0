/** \file record.h ADPCM Recording */
#if defined(__AVR_ATmega1280__)|| defined(__AVR_ATmega2560__)
#ifndef RECORD_H
#define RECORD_H

unsigned char Record();

#endif
#endif
